import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STORE = path.resolve(__dirname, 'network-bans.json');
const PORT = Number(process.env.API_PORT || 8787);
const OWNER_ID = process.env.OWNER_DISCORD_ID || '';
const API_KEY = process.env.NETWORK_API_KEY || '';
const ADMIN_KEY = process.env.NETWORK_ADMIN_KEY || '';
const MAX_BODY = 32_000;

if (!API_KEY || API_KEY.length < 32) {
  console.error('Set NETWORK_API_KEY to a random secret of at least 32 characters.');
  process.exit(1);
}
if (!OWNER_ID) {
  console.error('Set OWNER_DISCORD_ID to the Discord user ID allowed to manage network bans.');
  process.exit(1);
}
if (!ADMIN_KEY || ADMIN_KEY.length < 32) {
  console.error('Set NETWORK_ADMIN_KEY to a separate random secret of at least 32 characters.');
  process.exit(1);
}

let bans = [];
let writeQueue = Promise.resolve();

async function load() {
  try {
    const parsed = JSON.parse(await fs.readFile(STORE, 'utf8'));
    bans = Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    await persist();
  }
}
function persist() {
  writeQueue = writeQueue.then(async () => {
    const temp = `${STORE}.tmp`;
    await fs.writeFile(temp, JSON.stringify(bans, null, 2) + '\n', { mode: 0o600 });
    await fs.rename(temp, STORE);
  });
  return writeQueue;
}
function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(data),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
  });
  res.end(data);
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (Buffer.byteLength(body) > MAX_BODY) {
        reject(Object.assign(new Error('Request body too large'), { status: 413 }));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function validDiscordId(v) {
  return typeof v === 'string' && /^\d{17,20}$/.test(v);
}
function scrubBan(ban) {
  return {
    userId: ban.userId,
    reason: ban.reason,
    createdAt: ban.createdAt,
    expiresAt: ban.expiresAt,
    active: !ban.expiresAt || Date.parse(ban.expiresAt) > Date.now(),
    evidenceHash: ban.evidenceHash || null
  };
}
function auth(req, admin = false) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  return safeEqual(token, admin ? ADMIN_KEY : API_KEY);
}
function isOwner(body) {
  return typeof body.actorId === 'string' && safeEqual(body.actorId, OWNER_ID);
}
function audit(action, ban, actorId) {
  console.log(JSON.stringify({
    at: new Date().toISOString(),
    action,
    userId: ban?.userId || null,
    actorId: actorId || null
  }));
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const isWrite = (req.method === 'POST' && url.pathname === '/v1/bans') || (req.method === 'DELETE' && /^\/v1\/bans\/\d{17,20}$/.test(url.pathname));
    if (!auth(req, isWrite)) return send(res, 401, { error: 'Unauthorized' });

    if (req.method === 'GET' && url.pathname === '/health') {
      return send(res, 200, { ok: true, service: 'scam-image-guard-network-api' });
    }

    if (req.method === 'GET' && url.pathname === '/v1/bans') {
      const active = bans.filter(b => !b.expiresAt || Date.parse(b.expiresAt) > Date.now());
      return send(res, 200, { bans: active.map(scrubBan) });
    }

    const match = url.pathname.match(/^\/v1\/bans\/(\d{17,20})$/);
    if (req.method === 'GET' && match) {
      const ban = bans.find(b => b.userId === match[1] && (!b.expiresAt || Date.parse(b.expiresAt) > Date.now()));
      return ban ? send(res, 200, { banned: true, ban: scrubBan(ban) }) : send(res, 200, { banned: false });
    }

    if (req.method === 'POST' && url.pathname === '/v1/bans') {
      const body = await parseBody(req);
      if (!isOwner(body)) return send(res, 403, { error: 'Only the configured network owner may add network bans.' });
      if (!validDiscordId(body.userId)) return send(res, 400, { error: 'userId must be a Discord snowflake string.' });
      const reason = String(body.reason || '').trim().slice(0, 500);
      if (!reason) return send(res, 400, { error: 'A reason is required.' });
      let expiresAt = null;
      if (body.expiresAt != null && body.expiresAt !== '') {
        const date = new Date(body.expiresAt);
        if (!Number.isFinite(date.getTime()) || date.getTime() <= Date.now()) {
          return send(res, 400, { error: 'expiresAt must be a future ISO date/time.' });
        }
        expiresAt = date.toISOString();
      }
      const evidenceHash = typeof body.evidenceHash === 'string' && /^[a-f0-9]{64}$/i.test(body.evidenceHash)
        ? body.evidenceHash.toLowerCase() : null;
      const ban = {
        userId: body.userId,
        reason,
        createdAt: new Date().toISOString(),
        expiresAt,
        evidenceHash,
        createdBy: body.actorId,
        sourceGuildId: validDiscordId(body.sourceGuildId) ? body.sourceGuildId : null
      };
      bans = bans.filter(b => b.userId !== ban.userId);
      bans.push(ban);
      await persist();
      audit('ban.add', ban, body.actorId);
      return send(res, 201, { ok: true, ban: scrubBan(ban) });
    }

    if (req.method === 'DELETE' && match) {
      const body = await parseBody(req);
      if (!isOwner(body)) return send(res, 403, { error: 'Only the configured network owner may remove network bans.' });
      const before = bans.length;
      const removed = bans.find(b => b.userId === match[1]);
      bans = bans.filter(b => b.userId !== match[1]);
      if (before !== bans.length) await persist();
      audit('ban.remove', removed, body.actorId);
      return send(res, 200, { ok: true, removed: before !== bans.length });
    }

    return send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('API request error:', err.message);
    if (!res.headersSent) send(res, err.status || 500, { error: err.status ? err.message : 'Internal server error' });
  }
});

await load();
server.listen(PORT, '127.0.0.1', () => {
  console.log(`Network API listening on 127.0.0.1:${PORT}`);
  console.log('Put a TLS reverse proxy in front before exposing it to the internet.');
});
