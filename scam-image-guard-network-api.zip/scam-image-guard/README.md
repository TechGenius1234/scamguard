# Scam Image Guard

A free, local-first Discord bot that automatically scans uploaded images for scam indicators using OCR, URL parsing, QR-code extraction, and explainable heuristics. It uses Node.js, discord.js, `pnpm start`, JSON configuration, and JSON scan logs.

## What it can and cannot detect

- **Phishing:** OCR checks for account verification, login, password, and impersonation lures.
- **Giveaways:** OCR checks for suspicious reward, free Nitro/Robux, and prize language.
- **QR codes:** Detects a QR code and inspects its decoded text or URL without visiting it.
- **URLs:** Flags selected high-risk indicators such as punycode, raw-IP hostnames, selected risky TLDs, and URL shorteners.
- **Fake payment screenshots:** Flags payment/receipt claims for human review. It cannot reliably prove that a receipt is forged just from pixels.
- **Edited images:** Image metadata may be noted, but metadata is not proof of editing. Reliable manipulation detection needs a dedicated model and often still cannot prove fraud.
- **Other scams:** Extend phrase lists and rules in `config.json`.

This is a heuristic detector, not a guarantee. OCR can misread text, attackers can evade rules, and legitimate images can be flagged. Keep automatic deletion disabled until you have tested it.

## Requirements

- Node.js 20 or newer
- pnpm
- A Discord bot application/token

## Install on Windows

1. Create a folder for the bot and extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:

   ```powershell
   pnpm install
   Copy-Item .env.example .env
   notepad .env
   ```

4. Put your bot token in `.env`:

   ```dotenv
   DISCORD_TOKEN=your_real_bot_token
   ```

5. In the Discord Developer Portal, enable **Message Content Intent** for the bot.
6. Invite the bot to your server with **View Channels**, **Read Message History**, **Send Messages**, and **Embed Links**. Add **Manage Messages** only if you explicitly enable automatic deletion.
7. Set `moderation.alertChannelId` in `config.json` to a channel ID where alerts should be posted. Leave it blank to post alerts in the channel where the image was uploaded.
8. Start it:

   ```powershell
   pnpm start
   ```

The first OCR run may download the English language data for Tesseract.js. It is free, but the first run needs an internet connection. After dependencies and language data are available, OCR processing is local.

## Configuration

Open `config.json`.

- `enabled`: master on/off switch.
- `guildId`: optionally restrict scanning to one server. Blank means every server the bot is in.
- `minimumAlertScore`: score at which an alert is sent.
- `minimumHighRiskScore`: score classified as high risk.
- `moderation.mode`: currently informational; alerts are the default action.
- `moderation.deleteHighRiskImages`: defaults to `false`. If set to `true`, high-risk messages may be deleted if the bot has Manage Messages permission.
- `moderation.alertChannelId`: channel for alerts; blank means the original channel.
- `ignoredChannelIds`, `ignoredRoleIds`: exclusions.
- `maxAttachmentBytes`, `maxImagePixels`: resource limits.
- `trustedDomains`: exact trusted domains and their subdomains are exempted from some URL indicators. Do not add domains unless you trust them.
- `detection.suspiciousPhrases`, `phishingPhrases`, `paymentPhrases`, `giveawayPhrases`: customize the text rules.

Restart the bot after changing the JSON config.

## Safe URL handling

The bot extracts URLs from OCR and QR data, parses their hostnames, and checks simple indicators. **It does not visit extracted URLs, follow redirects, fetch website content, or submit links to third-party scanners.** Shortened URLs are flagged instead of expanded. This avoids accidentally opening malicious destinations or making the bot an SSRF proxy.

## Scan log and privacy

Scan records are written to `data/reports.json`, capped at the most recent 5,000 records. Records include Discord IDs, attachment URL, score, and findings. Attachment URLs may provide access to the image while valid, so protect this file and avoid sharing it publicly. Delete the log periodically if you do not need it.

## Discord permissions and intents

Enable **Message Content Intent** in the Developer Portal. The bot needs View Channel, Read Message History, Send Messages, and Embed Links in channels it scans. Manage Messages is only needed for optional deletion. It does not need Administrator.

## Troubleshooting

- `Missing DISCORD_TOKEN`: make sure `.env` exists and contains the token.
- No images scanned: enable Message Content Intent, check `enabled` and `scanImages`, and ensure the bot can view the channel.
- No alert: the score may be below `minimumAlertScore`; check `data/reports.json` and the console.
- OCR failure: ensure the machine can download Tesseract's English language data on first use.
- Bot cannot post in the alert channel: grant View Channel, Send Messages, and Embed Links there.

Never post your bot token publicly or commit `.env` to Git.


## Optional centralized network-ban API

The `network-api/` folder is a separate small Node.js service. It stores a shared list in `network-api/network-bans.json` and exposes authenticated endpoints for checking, adding, and removing bans. The bot only checks the API for new members when network bans and join enforcement are explicitly enabled.

### Run the API service

1. Deploy `network-api/` on a server reachable by your bot instances.
2. In that folder, copy `.env.example` to `.env` and set:
   - `OWNER_DISCORD_ID` to the single Discord user ID allowed to add/remove network bans.
   - `NETWORK_API_KEY` to a long random **read-only** secret (32+ characters) shared with bot instances.
   - `NETWORK_ADMIN_KEY` to a different long random secret (32+ characters) kept private for ban management.
   - `API_PORT` if needed.
3. Start with `node server.js` (the API has no third-party dependencies).
4. The service binds to `127.0.0.1` on purpose. Put it behind a TLS reverse proxy such as Caddy or nginx, and expose only HTTPS. Do not expose plain HTTP or the JSON file to the public internet.
5. On each bot instance, set in `.env`:
   - `NETWORK_API_URL=https://your-api-host.example`
   - `NETWORK_API_KEY=the_same_secret`
   - `NETWORK_OWNER_DISCORD_ID=your_discord_user_id`
6. In the bot's `config.json`, set `networkBans.enabled` and `networkBans.banOnJoin` to `true` only after testing. Set `networkBans.ownerDiscordId` to the same owner ID as an extra configuration reference. Enable **Server Members Intent** in the Developer Portal. The bot needs **Ban Members** permission and a role above the target user.

### API endpoints

Read endpoints require `Authorization: Bearer YOUR_NETWORK_API_KEY`. Write endpoints (`POST`/`DELETE`) require `Authorization: Bearer YOUR_NETWORK_ADMIN_KEY`. Keep the admin key off every bot instance and only use it from your private admin machine.

- `GET /health` — health check (also authenticated).
- `GET /v1/bans` — list active bans.
- `GET /v1/bans/DISCORD_USER_ID` — check one user.
- `POST /v1/bans` — add/update a ban; JSON body requires `actorId`, `userId`, and `reason`; optional `sourceGuildId`, `expiresAt`, `evidenceHash`.
- `DELETE /v1/bans/DISCORD_USER_ID` — remove a ban; JSON body requires `actorId`.

The API itself checks that `actorId` matches `OWNER_DISCORD_ID`. The current package provides the API and join-time enforcement hook; it does **not** yet add slash commands for adding/removing network bans. Manage the list from your private admin machine using the admin key. Never place the admin key in the bot's `.env`.

### Safety and scale notes

- Network-ban enforcement is opt-in and checks only when a member joins a server with this bot installed. It does not retroactively ban existing members.
- API failure is fail-open: the bot does not ban anyone when the API is unavailable.
- Only the configured network owner should be allowed to submit or remove network bans. In production, use per-bot API keys with server-side permissions, rate limiting, TLS, backups, and an audit log. This starter uses one shared API key and a JSON file; for high volume or multiple API writers, JSON-file persistence can become a bottleneck and should be replaced with a transactional database.
- A shared network ban can affect people across many independent communities. Keep evidence/reasons, use expiring bans where appropriate, provide a human review/appeal process, and do not automatically network-ban users solely because a scam-image heuristic flagged one image.
