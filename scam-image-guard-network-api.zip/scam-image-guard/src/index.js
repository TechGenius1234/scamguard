import 'dotenv/config';
import {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  PermissionsBitField
} from 'discord.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import jsQR from 'jsqr';
import { createWorker } from 'tesseract.js';
import { NetworkApi } from './networkApi.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const CONFIG_PATH = path.join(ROOT, 'config.json');
const REPORTS_PATH = path.join(ROOT, 'data', 'reports.json');

let config;
let ocrWorker = null;
let networkApi = null;
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

function log(...args) {
  console.log(new Date().toISOString(), ...args);
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, 'utf8'));
  } catch {
    return fallback;
  }
}

async function writeJson(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify(value, null, 2) + '\n', 'utf8');
}

function addFinding(findings, score, code, detail) {
  if (!findings.some(f => f.code === code && f.detail === detail)) {
    findings.push({ score, code, detail });
  }
}

function normalizeText(s) {
  return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function extractUrls(text) {
  const found = new Set();
  const re = /(?:https?:\/\/|www\.)[^\s<>"'`]+/gi;
  for (const match of String(text || '').matchAll(re)) {
    let raw = match[0].replace(/[),.!?;:}\]]+$/g, '');
    if (raw.startsWith('www.')) raw = `https://${raw}`;
    try {
      const u = new URL(raw);
      if (u.protocol === 'http:' || u.protocol === 'https:') found.add(u.href);
    } catch {}
  }
  return [...found];
}

function hostnameOf(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return '';
  }
}

function isTrusted(host, trustedDomains) {
  return trustedDomains.some(domain => {
    const d = String(domain).toLowerCase().trim();
    return d && (host === d || host.endsWith(`.${d}`));
  });
}

function inspectUrl(url, findings, cfg) {
  const host = hostnameOf(url);
  if (!host) return;
  const trusted = isTrusted(host, cfg.moderation.trustedDomains || []);
  let points = 0;

  if (host.startsWith('xn--') || host.split('.').some(part => part.startsWith('xn--'))) {
    points += 30;
    addFinding(findings, 30, 'PUNYCODE_DOMAIN', `URL uses an internationalized/punycode hostname: ${host}`);
  }
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) {
    points += 35;
    addFinding(findings, 35, 'IP_ADDRESS_URL', `URL uses a raw IP address instead of a normal domain: ${host}`);
  }
  const tlds = cfg.detection.suspiciousTlds || [];
  if (!trusted && tlds.some(tld => host.endsWith(tld))) {
    points += 18;
    addFinding(findings, 18, 'SUSPICIOUS_TLD', `URL uses a higher-risk top-level domain: ${host}`);
  }
  if (!trusted && (cfg.detection.urlShorteners || []).includes(host)) {
    points += 12;
    addFinding(findings, 12, 'SHORT_URL', `URL uses a link-shortening service; final destination is not opened: ${host}`);
  }
  if (url.length > 150) {
    points += 8;
    addFinding(findings, 8, 'LONG_URL', 'URL is unusually long and may hide its real destination.');
  }
  if (/@/.test(new URL(url).pathname + new URL(url).search)) {
    points += 10;
    addFinding(findings, 10, 'URL_AT_SIGN', 'URL contains an @ character in its path or query; inspect carefully.');
  }
  if (!trusted && /(?:discord|steam|roblox|paypal|wallet|verify|gift|nitro|login|secure|claim)/i.test(host)) {
    points += 10;
    addFinding(findings, 10, 'BRAND_BAIT_DOMAIN', `Hostname contains words commonly used in impersonation links: ${host}`);
  }
  return points;
}

function scoreText(text, findings, cfg) {
  const normalized = normalizeText(text);
  if (!normalized) return;
  for (const phrase of cfg.detection.suspiciousPhrases || []) {
    if (normalized.includes(phrase.toLowerCase())) {
      addFinding(findings, 12, 'SUSPICIOUS_TEXT', `Image text contains a scam-associated phrase: "${phrase}"`);
    }
  }
  for (const phrase of cfg.detection.phishingPhrases || []) {
    if (normalized.includes(phrase.toLowerCase())) {
      addFinding(findings, 18, 'PHISHING_TEXT', `Image text resembles a credential or account-verification lure: "${phrase}"`);
    }
  }
  for (const phrase of cfg.detection.paymentPhrases || []) {
    if (normalized.includes(phrase.toLowerCase())) {
      addFinding(findings, 10, 'PAYMENT_PROOF_TEXT', `Image appears to claim a payment or transaction: "${phrase}". This is not proof the receipt is fake.`);
    }
  }
  for (const phrase of cfg.detection.giveawayPhrases || []) {
    if (normalized.includes(phrase.toLowerCase())) {
      addFinding(findings, 16, 'GIVEAWAY_TEXT', `Image text resembles a giveaway/reward lure: "${phrase}"`);
    }
  }
  if (/(password|passcode|seed phrase|recovery phrase).{0,35}(enter|submit|share|send|provide)/i.test(normalized)) {
    addFinding(findings, 35, 'SECRET_REQUEST', 'Image appears to ask for a password, passcode, seed phrase, or recovery phrase.');
  }
  if (/(send|pay|transfer).{0,30}(crypto|bitcoin|eth|gift card|friends and family)/i.test(normalized)) {
    addFinding(findings, 20, 'PAYMENT_REQUEST', 'Image appears to request an unusual or hard-to-reverse payment.');
  }
}

async function getOcrWorker() {
  if (!ocrWorker) {
    ocrWorker = await createWorker('eng');
  }
  return ocrWorker;
}

async function downloadAttachment(attachment, maxBytes) {
  if (!attachment.contentType?.startsWith('image/')) throw new Error('Not an image content type');
  if (attachment.size > maxBytes) throw new Error(`Image exceeds ${maxBytes} byte limit`);
  const url = new URL(attachment.url);
  if (url.protocol !== 'https:' || !['cdn.discordapp.com', 'media.discordapp.net'].includes(url.hostname)) {
    throw new Error('Attachment URL was not a recognized Discord CDN URL');
  }
  const response = await fetch(url, { redirect: 'error', signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Image download failed (${response.status})`);
  const declaredLength = Number(response.headers.get('content-length') || 0);
  if (declaredLength > maxBytes) throw new Error('Image exceeds configured size limit');
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > maxBytes) throw new Error('Image exceeds configured size limit');
  return buffer;
}

async function inspectImage(buffer, cfg) {
  const findings = [];
  let metadata;
  try {
    metadata = await sharp(buffer, { limitInputPixels: cfg.maxImagePixels }).metadata();
  } catch {
    addFinding(findings, 0, 'UNREADABLE_IMAGE', 'Image could not be decoded safely; no verdict was made.');
    return { score: 0, findings, extractedText: '', urls: [], metadata: null };
  }

  if (!metadata.width || !metadata.height || metadata.width * metadata.height > cfg.maxImagePixels) {
    throw new Error('Image dimensions exceed the configured pixel limit');
  }

  let extractedText = '';
  if (cfg.detection.ocrEnabled) {
    try {
      const worker = await getOcrWorker();
      const result = await worker.recognize(buffer);
      extractedText = result.data.text || '';
      scoreText(extractedText, findings, cfg);
    } catch (err) {
      log('OCR warning:', err.message);
      addFinding(findings, 0, 'OCR_UNAVAILABLE', 'OCR failed; text-based checks may be incomplete.');
    }
  }

  const urls = extractUrls(extractedText);
  for (const url of urls) inspectUrl(url, findings, cfg);

  if (cfg.detection.qrEnabled) {
    try {
      const { data, info } = await sharp(buffer, { limitInputPixels: cfg.maxImagePixels })
        .rotate()
        .resize({ width: 1400, height: 1400, fit: 'inside', withoutEnlargement: true })
        .ensureAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });
      const qr = jsQR(new Uint8ClampedArray(data), info.width, info.height, { inversionAttempts: 'attemptBoth' });
      if (qr?.data) {
        addFinding(findings, 8, 'QR_CODE_FOUND', 'A QR code was detected in the image.');
        const qrText = qr.data.trim();
        if (/^https?:\/\//i.test(qrText)) {
          const qrUrls = extractUrls(qrText);
          for (const url of qrUrls) inspectUrl(url, findings, cfg);
          if (!urls.includes(qrText)) urls.push(qrText);
        } else if (/(seed phrase|password|wallet|payment|bitcoin|crypto)/i.test(qrText)) {
          addFinding(findings, 25, 'QR_SENSITIVE_CONTENT', 'QR code contains text associated with credentials, wallets, or payments.');
        }
      }
    } catch (err) {
      log('QR scan warning:', err.message);
    }
  }

  // Metadata can suggest re-encoding or editing, but is not proof of manipulation.
  if (metadata.software || metadata.exif || metadata.iptc || metadata.xmp) {
    addFinding(findings, 2, 'IMAGE_METADATA_PRESENT', 'Image contains metadata. Metadata alone is not evidence of fraud.');
  }
  if (metadata.format === 'svg') {
    addFinding(findings, 0, 'VECTOR_IMAGE', 'Vector image format; some image analysis may be limited.');
  }

  const score = Math.min(100, findings.reduce((sum, f) => sum + f.score, 0));
  return { score, findings, extractedText, urls, metadata: { format: metadata.format, width: metadata.width, height: metadata.height } };
}

function severity(score, cfg) {
  if (score >= cfg.minimumHighRiskScore) return 'HIGH';
  if (score >= cfg.minimumAlertScore) return 'SUSPICIOUS';
  return 'LOW';
}

function makeEmbed(result, message, attachment) {
  const level = severity(result.score, config);
  const color = level === 'HIGH' ? 0xD83C3E : level === 'SUSPICIOUS' ? 0xE6A23C : 0x3BA55D;
  const embed = new EmbedBuilder()
    .setTitle(`Image scan: ${level} (${result.score}/100)`)
    .setColor(color)
    .setDescription(`Image uploaded by ${message.author} in <#${message.channelId}>.\n[Open original image](${attachment.url})`)
    .addFields(
      { name: 'Assessment', value: result.findings.length ? result.findings.slice(0, 12).map(f => `• **+${f.score}** ${f.detail}`).join('\n').slice(0, 1024) : 'No configured scam indicators were detected.', inline: false },
      { name: 'Important', value: 'This is a heuristic risk estimate, not proof that an image is fraudulent. Review context before taking action.', inline: false }
    )
    .setFooter({ text: `Message ID: ${message.id} • User ID: ${message.author.id}` })
    .setTimestamp();
  if (result.metadata) embed.addFields({ name: 'Image details', value: `${result.metadata.format || 'unknown'} • ${result.metadata.width || '?'}×${result.metadata.height || '?'}`, inline: true });
  return embed;
}

async function sendAlert(message, attachment, result) {
  const level = severity(result.score, config);
  if (level === 'LOW') return;
  const channelId = config.moderation.alertChannelId;
  let channel = null;
  if (channelId) {
    channel = await client.channels.fetch(channelId).catch(() => null);
  }
  if (!channel?.isTextBased()) {
    channel = message.channel;
  }

  const embed = makeEmbed(result, message, attachment);
  await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(err => log('Alert send failed:', err.message));

  if (
    level === 'HIGH' &&
    config.moderation.deleteHighRiskImages === true &&
    message.guild &&
    message.guild.members.me?.permissionsIn(message.channel).has(PermissionsBitField.Flags.ManageMessages)
  ) {
    await message.delete().catch(err => log('Could not delete flagged message:', err.message));
  }
}

async function saveReport(message, attachment, result) {
  const reports = await readJson(REPORTS_PATH, []);
  reports.push({
    scannedAt: new Date().toISOString(),
    guildId: message.guildId,
    channelId: message.channelId,
    messageId: message.id,
    userId: message.author.id,
    attachmentName: attachment.name,
    attachmentUrl: attachment.url,
    score: result.score,
    severity: severity(result.score, config),
    findings: result.findings
  });
  await writeJson(REPORTS_PATH, reports.slice(-5000));
}

client.once('ready', () => {
  log(`Logged in as ${client.user.tag}`);
  log('Automatic image scanning is enabled:', Boolean(config.enabled && config.scanImages));
});

client.on('messageCreate', async message => {
  if (!config.enabled || !config.scanImages || !message.guild || message.author?.bot && config.moderation.ignoreBots) return;
  if (config.guildId && message.guildId !== config.guildId) return;
  if ((config.moderation.ignoredChannelIds || []).includes(message.channelId)) return;
  if ((message.member?.roles?.cache?.map(r => r.id) || []).some(id => (config.moderation.ignoredRoleIds || []).includes(id))) return;

  const attachments = [...message.attachments.values()].filter(a => {
    const mime = a.contentType || '';
    if (!mime.startsWith('image/')) return false;
    if (mime === 'image/gif' && !config.scanGifs) return false;
    return true;
  });
  for (const attachment of attachments.slice(0, 4)) {
    try {
      const buffer = await downloadAttachment(attachment, config.maxAttachmentBytes);
      const result = await inspectImage(buffer, config);
      await saveReport(message, attachment, result);
      await sendAlert(message, attachment, result);
      log(`Scanned ${attachment.name} by ${message.author.tag}: ${result.score}/100 (${severity(result.score, config)})`);
    } catch (err) {
      log(`Scan failed for ${attachment.name}:`, err.message);
    }
  }
});


client.on('guildMemberAdd', async member => {
  if (!config.networkBans?.enabled || !config.networkBans?.banOnJoin || !networkApi?.enabled) return;
  if (config.guildId && member.guild.id !== config.guildId) return;
  try {
    const result = await networkApi.check(member.id);
    if (!result?.banned || !result.ban) return;
    const me = member.guild.members.me;
    if (!me?.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      log(`Network ban match for ${member.id} in ${member.guild.id}, but bot lacks Ban Members.`);
      return;
    }
    const reason = `Network ban: ${String(result.ban.reason || 'No reason supplied').slice(0, 400)} | Network API`;
    await member.ban({ reason });
    log(`Applied network ban to ${member.id} in guild ${member.guild.id}`);
    const notifyId = config.networkBans.notifyChannelId || config.moderation.alertChannelId;
    if (notifyId) {
      const ch = await client.channels.fetch(notifyId).catch(() => null);
      if (ch?.isTextBased()) {
        await ch.send({
          embeds: [new EmbedBuilder()
            .setTitle('Network ban applied')
            .setColor(0xD83C3E)
            .setDescription(`Banned <@${member.id}> after they joined **${member.guild.name}**.\n**Network reason:** ${String(result.ban.reason || 'Not provided').slice(0, 700)}`)
            .setFooter({ text: `User ID: ${member.id}` })
            .setTimestamp()],
          allowedMentions: { parse: [] }
        }).catch(() => {});
      }
    }
  } catch (err) {
    // API outages never trigger a ban. This is intentionally fail-open.
    log(`Network ban lookup failed for ${member.id}:`, err.message);
  }
});

process.on('unhandledRejection', err => log('Unhandled rejection:', err));
process.on('uncaughtException', err => {
  log('Uncaught exception:', err);
});

async function main() {
  config = await readJson(CONFIG_PATH, null);
  if (!config) throw new Error('Could not read config.json');
  if (!process.env.DISCORD_TOKEN) throw new Error('Missing DISCORD_TOKEN. Copy .env.example to .env and set your bot token.');
  await fs.mkdir(path.dirname(REPORTS_PATH), { recursive: true });
  const ownerId = process.env.NETWORK_OWNER_DISCORD_ID || config.networkBans?.ownerDiscordId || '';
  networkApi = new NetworkApi({
    baseUrl: process.env.NETWORK_API_URL,
    apiKey: process.env.NETWORK_API_KEY,
    ownerId
  });
  if (config.networkBans?.enabled && !networkApi.enabled) {
    log('Network bans are enabled in config but NETWORK_API_URL/NETWORK_API_KEY are not configured; network bans will remain inactive.');
  }
  await client.login(process.env.DISCORD_TOKEN);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
