export class NetworkApi {
  constructor({ baseUrl, apiKey, ownerId }) {
    this.baseUrl = String(baseUrl || '').replace(/\/+$/, '');
    this.apiKey = apiKey || '';
    this.ownerId = ownerId || '';
    this.enabled = Boolean(this.baseUrl && this.apiKey);
  }

  async request(path, options = {}) {
    if (!this.enabled) return null;
    const response = await fetch(`${this.baseUrl}${path}`, {
      ...options,
      headers: {
        authorization: `Bearer ${this.apiKey}`,
        'content-type': 'application/json',
        ...(options.headers || {})
      },
      signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(`Network API ${response.status}: ${body.error || 'request failed'}`);
    }
    return response.json();
  }

  async check(userId) {
    if (!this.enabled) return { banned: false, unavailable: true };
    return await this.request(`/v1/bans/${encodeURIComponent(userId)}`);
  }

  async add({ userId, reason, actorId, sourceGuildId, expiresAt, evidenceHash }) {
    if (!this.enabled) throw new Error('Network API is not configured.');
    return this.request('/v1/bans', {
      method: 'POST',
      body: JSON.stringify({ userId, reason, actorId, sourceGuildId, expiresAt, evidenceHash })
    });
  }

  async remove({ userId, actorId }) {
    if (!this.enabled) throw new Error('Network API is not configured.');
    return this.request(`/v1/bans/${encodeURIComponent(userId)}`, {
      method: 'DELETE',
      body: JSON.stringify({ actorId })
    });
  }
}
